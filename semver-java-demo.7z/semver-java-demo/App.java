﻿public class App {
    public static void main(String[] args) {
        System.out.println("Hello World! Version 1.0.0");
        
        System.out.println("Version: " + getVersion());
        
        if (args.length > 0) {
            System.out.println(greetUser(args[0]));
        } else {
            System.out.println(greetUser("Guest"));
        }
    }
    
    public static String getVersion() {
        return "1.0.0";
    }
    
    public static String greetUser(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "Hello, Guest!";
        }
        return "Hello, " + name + "!";
    }
}
